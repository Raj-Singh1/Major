'use strict';
import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css'

class Home extends Component {
  render() {
    return (
        <div>

  <h3>Home</h3>
</div>
    );
  }
}

export default Home;
