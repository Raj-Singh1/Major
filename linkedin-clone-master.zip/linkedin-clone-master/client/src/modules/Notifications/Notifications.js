'use strict';
import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css'

class Notifications extends Component {
  render() {
    return (
        <div>

  <h3>Notifications</h3>
</div>
    );
  }
}

export default Notifications;
