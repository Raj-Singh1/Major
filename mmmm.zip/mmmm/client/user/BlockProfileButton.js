import React, {Component} from 'react'
import PropTypes from 'prop-types'
import {withStyles} from 'material-ui/styles'
import Button from 'material-ui/Button'
import {unblock, block} from './api-user.js'


class BlockProfileButton extends Component {
  blockClick = () => {
    this.props.onButtonClick(Block)
  }
  unblockClick = () => {
    this.props.onButtonClick(UnBlock)
  }
  render() {
    return (<div>
      { this.props.blocking
        ? (<Button variant="raised" color="secondary" onClick={this.unblockClick}>UnBlock</Button>)
        : (<Button variant="raised" color="primary" onClick={this.blockClick}>Block</Button>)
      }
    </div>)
  }
}
BlockProfileButton.PropTypes = {
  blocking : PropTypes.bool.isRequired,
  onButtonClick : PropTypes.func.isRequired
}


export default BlockProfileButton
