show DATABASES;
select * from userdetails;

use cmpe_282;