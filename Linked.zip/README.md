Steps
------
1. In the root directory fire the following command to install the required node packages

	npm install

2. Start the node server on Port 3000 

	npm start